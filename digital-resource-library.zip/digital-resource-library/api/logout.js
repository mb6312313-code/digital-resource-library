module.exports = async function handler(req, res) {
  if (req.method !== "POST") {
    res.status(405).json({ message: "Method not allowed" });
    return;
  }

  res.setHeader("Set-Cookie", "library_auth=; Path=/; HttpOnly; SameSite=Lax; Secure; Max-Age=0");
  res.status(200).json({ ok: true });
};
