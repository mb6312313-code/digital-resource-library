const crypto = require("crypto");

function sign(payload, secret) {
  return crypto.createHmac("sha256", secret).update(payload).digest("base64url");
}

module.exports = async function handler(req, res) {
  if (req.method !== "POST") {
    res.status(405).json({ message: "Method not allowed" });
    return;
  }

  const password = process.env.SITE_PASSWORD;
  if (!password) {
    res.status(500).json({ message: "SITE_PASSWORD is not configured on Vercel." });
    return;
  }

  const submitted = req.body && req.body.password;
  if (typeof submitted !== "string" || submitted !== password) {
    res.status(401).json({ message: "Wrong password. Please try again." });
    return;
  }

  const timestamp = Date.now().toString();
  const signature = sign(timestamp, password);
  const cookie = `library_auth=${timestamp}.${signature}; Path=/; HttpOnly; SameSite=Lax; Secure; Max-Age=2592000`;
  res.setHeader("Set-Cookie", cookie);
  res.status(200).json({ ok: true });
};
